﻿using System;
using System.Text;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        // Specifications
        string registrationNumber = "011";
        string firstName = "sara";
        string lastName = "ali";
        string favoriteMovie = "vampire";

        // Extract components
        string digits = registrationNumber.Substring(0, 2); // First two digits
        string secondLetters = firstName[1] + "" + lastName[1]; // Second letters of first and last name
        string charactersFromMovie = favoriteMovie.Substring(0, 2); // First two characters from favorite movie
        string specialCharacters = "!@$%^&*()-_+=<>?"; // Define special characters

        // Create password components
        StringBuilder password = new StringBuilder();
        password.Append(digits);
        password.Append(secondLetters);
        password.Append(charactersFromMovie);
        password.Append(GetRandomSpecialCharacter(specialCharacters)); // Add random special character
        password.Append(GetRandomSpecialCharacter(specialCharacters)); // Add another random special character
        password.Append(GetRandomNumber(10)); // Add a random digit

        // Ensure the password is exactly 14 characters long
        while (password.Length < 14)
        {
            password.Append(GetRandomCharacter()); // Fill remaining length with random characters
        }

        // Shuffle the password to randomize the order
        string finalPassword = Shuffle(password.ToString());

        // Display the password
        Console.WriteLine("Generated Password: " + finalPassword);
    }

    // Method to get a random special character
    static char GetRandomSpecialCharacter(string specialCharacters)
    {
        Random random = new Random();
        return specialCharacters[random.Next(specialCharacters.Length)];
    }

    // Method to get a random number
    static char GetRandomNumber(int range)
    {
        Random random = new Random();
        return (char)('0' + random.Next(range)); // Generates a random digit character
    }

    // Method to get a random character (alphanumeric)
    static char GetRandomCharacter()
    {
        Random random = new Random();
        char[] characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".ToCharArray();
        return characters[random.Next(characters.Length)];
    }

    // Method to shuffle the characters in the password
    static string Shuffle(string input)
    {
        Random random = new Random();
        char[] array = input.ToCharArray();
        for (int i = 0; i < array.Length; i++)
        {
            int j = random.Next(i, array.Length);
            char temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
        return new string(array);
    }
}
